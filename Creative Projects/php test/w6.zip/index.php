<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <?php
            echo("Gargbage Wang");
            $list = array("queenOfPeace", "queenOfLove");
            echo(count($list) . "<br>");
            echo(sizeOf($list));
        ?>
    </body>
</html>